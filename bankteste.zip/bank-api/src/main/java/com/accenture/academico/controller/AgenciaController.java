package com.accenture.academico.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.academy.service.PessoaService;

@RestController
@RequestMapping("/sistema")


public class AgenciaController {

	
	@Autowired
	AgenciaService agenciaservice;
	
}
