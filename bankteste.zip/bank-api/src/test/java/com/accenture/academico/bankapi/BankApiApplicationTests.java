package com.accenture.academico.bankapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
